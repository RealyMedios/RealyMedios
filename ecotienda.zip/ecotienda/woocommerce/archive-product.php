<?php get_header('shop'); ?>

<main id="primary" class="site-main">
    <?php if (apply_filters('woocommerce_show_page_title', true)) : ?>
        <div class="shop-banner">
            <div class="container">
                <h1 class="shop-title"><?php woocommerce_page_title(); ?></h1>
                <?php do_action('woocommerce_archive_description'); ?>
            </div>
        </div>
    <?php endif; ?>

    <div class="container">
        <div class="shop-content">
            <div class="shop-controls">
                <?php do_action('woocommerce_before_shop_loop'); ?>
            </div>

            <div class="shop-layout">
                <button class="filter-toggle">
                    <?php esc_html_e('Filtros', 'ecotienda'); ?>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="4" y1="6" x2="20" y2="6"/>
                        <line x1="8" y1="12" x2="16" y2="12"/>
                        <line x1="10" y1="18" x2="14" y2="18"/>
                    </svg>
                </button>

                <aside class="shop-sidebar">
                    <?php if (is_active_sidebar('sidebar-shop')) : ?>
                        <?php dynamic_sidebar('sidebar-shop'); ?>
                    <?php else : ?>
                        <?php do_action('woocommerce_sidebar'); ?>
                    <?php endif; ?>
                </aside>

                <div class="products-area">
                    <?php if (woocommerce_product_loop()) : ?>
                        <?php woocommerce_product_loop_start(); ?>
                        <?php if (wc_get_loop_prop('total')) : ?>
                            <?php while (have_posts()) : the_post(); ?>
                                <?php wc_get_template_part('content', 'product'); ?>
                            <?php endwhile; ?>
                        <?php endif; ?>
                        <?php woocommerce_product_loop_end(); ?>
                        <?php do_action('woocommerce_after_shop_loop'); ?>
                    <?php else : ?>
                        <?php do_action('woocommerce_no_products_found'); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</main>

<?php get_footer('shop'); ?>
