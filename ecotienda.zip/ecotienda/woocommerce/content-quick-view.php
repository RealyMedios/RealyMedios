<?php defined('ABSPATH') || exit; ?>

<?php
global $product;

if (!$product) {
    return;
}
?>

<div class="quick-view-modal">
    <div class="quick-view-content">
        <button class="quick-view-close">&times;</button>
        <div class="quick-view-product">
            <div class="quick-view-images">
                <?php echo $product->get_image('woocommerce_single'); ?>
            </div>
            <div class="quick-view-summary">
                <h2 class="quick-view-title"><?php echo esc_html($product->get_name()); ?></h2>
                <div class="quick-view-price"><?php echo $product->get_price_html(); ?></div>
                <div class="quick-view-excerpt"><?php echo wp_kses_post($product->get_short_description()); ?></div>
                <a href="<?php echo esc_url($product->get_permalink()); ?>" class="btn btn-primary">
                    <?php esc_html_e('Ver producto completo', 'ecotienda'); ?>
                </a>
            </div>
        </div>
    </div>
</div>
