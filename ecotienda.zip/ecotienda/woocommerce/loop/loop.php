<?php defined('ABSPATH') || exit; ?>

<div class="products-loop">
    <?php if (wc_get_loop_prop('total')) : ?>
        <?php while (have_posts()) : the_post(); ?>
            <?php wc_get_template_part('content', 'product'); ?>
        <?php endwhile; ?>
    <?php endif; ?>
</div>
