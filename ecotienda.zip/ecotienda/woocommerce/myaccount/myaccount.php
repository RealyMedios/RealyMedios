<?php defined('ABSPATH') || exit; ?>

<div class="myaccount-page">
    <h1 class="myaccount-title"><?php esc_html_e('Mi Cuenta', 'ecotienda'); ?></h1>

    <?php do_action('woocommerce_account_navigation'); ?>

    <div class="woocommerce-MyAccount-content">
        <?php do_action('woocommerce_account_content'); ?>
    </div>
</div>
