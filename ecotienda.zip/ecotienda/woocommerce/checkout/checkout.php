<?php defined('ABSPATH') || exit; ?>

<?php wc_print_notices(); ?>

<div class="checkout-page">
    <h1 class="checkout-title"><?php esc_html_e('Finalizar Compra', 'ecotienda'); ?></h1>

    <?php do_action('woocommerce_before_checkout_form', $checkout); ?>

    <?php if ($checkout->is_registration_enabled() && !$checkout->is_registration_required()) : ?>
        <div class="checkout-login">
            <?php do_action('woocommerce_checkout_login_form'); ?>
        </div>
    <?php endif; ?>

    <form name="checkout" method="post" class="checkout woocommerce-checkout" action="<?php echo esc_url(wc_get_checkout_url()); ?>" enctype="multipart/form-data">
        <div class="checkout-layout">
            <div class="checkout-billing">
                <?php if ($checkout->get_checkout_fields()) : ?>
                    <?php do_action('woocommerce_checkout_before_customer_details'); ?>
                    <div class="col2-set" id="customer_details">
                        <div class="col-1">
                            <?php do_action('woocommerce_checkout_billing'); ?>
                        </div>
                        <div class="col-2">
                            <?php do_action('woocommerce_checkout_shipping'); ?>
                        </div>
                    </div>
                    <?php do_action('woocommerce_checkout_after_customer_details'); ?>
                <?php endif; ?>
            </div>

            <div class="checkout-summary">
                <div class="checkout-order-review">
                    <h3 id="order_review_heading"><?php esc_html_e('Resumen del pedido', 'ecotienda'); ?></h3>
                    <?php do_action('woocommerce_checkout_before_order_review'); ?>
                    <div id="order_review" class="woocommerce-checkout-review-order">
                        <?php do_action('woocommerce_checkout_order_review'); ?>
                    </div>
                    <?php do_action('woocommerce_checkout_after_order_review'); ?>
                </div>
            </div>
        </div>
    </form>

    <?php do_action('woocommerce_after_checkout_form', $checkout); ?>
</div>
