<?php defined('ABSPATH') || exit; ?>

<?php
global $product;

if (empty($product) || !$product->is_visible()) {
    return;
}
?>

<li <?php wc_product_class('', $product); ?>>
    <?php do_action('woocommerce_before_shop_loop_item'); ?>

    <a href="<?php the_permalink(); ?>" class="woocommerce-loop-product__link">
        <?php do_action('woocommerce_before_shop_loop_item_title'); ?>

        <div class="product-details">
            <?php do_action('woocommerce_shop_loop_item_title'); ?>
            <?php do_action('woocommerce_after_shop_loop_item_title'); ?>
        </div>
    </a>

    <?php do_action('woocommerce_after_shop_loop_item'); ?>
</li>
