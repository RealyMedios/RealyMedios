<?php get_header(); ?>

<main id="primary" class="site-main">
    <div class="container">
        <?php if (have_posts()) : ?>
            <div class="blog-grid">
                <?php while (have_posts()) : the_post(); ?>
                    <?php get_template_part('template-parts/content', get_post_type()); ?>
                <?php endwhile; ?>
            </div>
            <?php the_posts_pagination([
                'mid_size' => 2,
                'prev_text' => __('&laquo; Anterior', 'ecotienda'),
                'next_text' => __('Siguiente &raquo;', 'ecotienda'),
            ]); ?>
        <?php else : ?>
            <?php get_template_part('template-parts/content', 'none'); ?>
        <?php endif; ?>
    </div>
</main>

<?php get_footer(); ?>
