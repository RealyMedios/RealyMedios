    <footer id="colophon" class="site-footer">
        <?php if (is_active_sidebar('footer-1') || is_active_sidebar('footer-2') || is_active_sidebar('footer-3') || is_active_sidebar('footer-4')) : ?>
        <div class="footer-widgets">
            <div class="container">
                <div class="footer-grid">
                    <div class="footer-col"><?php dynamic_sidebar('footer-1'); ?></div>
                    <div class="footer-col"><?php dynamic_sidebar('footer-2'); ?></div>
                    <div class="footer-col"><?php dynamic_sidebar('footer-3'); ?></div>
                    <div class="footer-col"><?php dynamic_sidebar('footer-4'); ?></div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <div class="footer-bottom">
            <div class="container">
                <div class="footer-bottom-inner">
                    <div class="footer-copyright">
                        &copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. 
                        <?php esc_html_e('Todos los derechos reservados.', 'ecotienda'); ?>
                    </div>
                    <div class="footer-menu">
                        <?php
                        wp_nav_menu([
                            'theme_location' => 'footer',
                            'menu_id' => 'footer-menu',
                            'container' => false,
                            'depth' => 1,
                            'fallback_cb' => false,
                        ]);
                        ?>
                    </div>
                    <div class="footer-payments">
                        <span><?php esc_html_e('Pagos seguros:', 'ecotienda'); ?></span>
                        <img src="<?php echo ECOTIENDA_URI; ?>/assets/img/payments.svg" alt="<?php esc_attr_e('Métodos de pago', 'ecotienda'); ?>" width="200" height="30"/>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <div class="mobile-menu-overlay"></div>
    <nav class="mobile-menu-panel">
        <div class="mobile-menu-header">
            <span class="mobile-menu-title"><?php esc_html_e('Menú', 'ecotienda'); ?></span>
            <button class="mobile-menu-close">&times;</button>
        </div>
        <?php
        wp_nav_menu([
            'theme_location' => 'mobile',
            'menu_class' => 'mobile-menu',
            'container' => false,
            'fallback_cb' => 'ecotienda_mobile_fallback',
        ]);
        ?>
    </nav>
</div>

<?php wp_footer(); ?>
</body>
</html>
