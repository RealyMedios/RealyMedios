(function ($) {
    'use strict';

    /**
     * AJAX Add to Cart
     */
    function initAjaxAddToCart() {
        $(document).on('submit', '.cart', function (e) {
            const $form = $(this);
            if ($form.hasClass('variations_form')) {
                return;
            }

            const $button = $form.find('.single_add_to_cart_button');
            if ($button.hasClass('disabled')) {
                return;
            }

            e.preventDefault();

            const formData = $form.serializeArray();
            formData.push({ name: 'action', value: 'ecotienda_add_to_cart' });

            $button.addClass('loading');
            const originalText = $button.text();
            $button.text('Agregando...');

            $.post(ecotiendaData.ajaxUrl, formData, function (response) {
                if (response.success) {
                    $('.cart-count').text(response.data.count);
                    $('.cart-total').text(response.data.total);

                    showNotice(response.data.message, 'success');

                    $button.text('Agregado!');
                    setTimeout(function () {
                        $button.removeClass('loading').text(originalText);
                    }, 1500);
                } else {
                    showNotice(response.data.message, 'error');
                    $button.removeClass('loading').text(originalText);
                }
            }).fail(function () {
                showNotice('Error al conectar con el servidor', 'error');
                $button.removeClass('loading').text(originalText);
            });
        });
    }

    /**
     * Show floating notice
     */
    function showNotice(message, type) {
        const noticeClass = type === 'success'
            ? 'woocommerce-message'
            : 'woocommerce-error';

        const $notice = $('<div class="floating-notice ' + noticeClass + '">' +
            '<span>' + message + '</span>' +
            '<button class="notice-close">&times;</button>' +
            '</div>');

        $('body').append($notice);

        $notice.css({
            position: 'fixed',
            top: '20px',
            right: '20px',
            zIndex: 9999,
            minWidth: '300px',
            animation: 'slideInRight 0.3s ease',
            boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
        });

        $notice.find('.notice-close').on('click', function () {
            $notice.fadeOut(300, function () { $(this).remove(); });
        });

        setTimeout(function () {
            $notice.fadeOut(300, function () { $(this).remove(); });
        }, 4000);
    }

    /**
     * Variation Swatches
     */
    function initVariationSwatches() {
        $(document).on('found_variation', '.variations_form', function (event, variation) {
            const $form = $(this);
            const $button = $form.find('.single_add_to_cart_button');

            if (variation.is_in_stock && variation.price_html) {
                $('.product .price').html(variation.price_html);
                $button.removeClass('disabled').text('Agregar al carrito');
            } else {
                $button.addClass('disabled').text('Agotado');
            }
        });

        $(document).on('reset_data', '.variations_form', function () {
            const $form = $(this);
            $form.find('.single_add_to_cart_button')
                .addClass('disabled')
                .text('Selecciona opciones');
        });
    }

    /**
     * Mini cart update
     */
    function initCartFragments() {
        $(document.body).on('added_to_cart removed_from_cart', function () {
            $(document.body).trigger('wc_fragment_refresh');
        });
    }

    /**
     * Checkout form improvements
     */
    function initCheckoutEnhancements() {
        if (!$('.woocommerce-checkout').length) {
            return;
        }

        const $stateField = $('#billing_state, #shipping_state');
        const $countryField = $('#billing_country, #shipping_country');

        $countryField.on('change', function () {
            const $row = $(this).closest('.form-row');
            $row.addClass('loading');
            setTimeout(function () {
                $row.removeClass('loading');
            }, 1000);
        });

        $('.woocommerce-checkout input, .woocommerce-checkout select').on('focus', function () {
            $(this).closest('.form-row').addClass('focused');
        }).on('blur', function () {
            $(this).closest('.form-row').removeClass('focused');
        });
    }

    /**
     * Product gallery enhancements
     */
    function initGalleryEnhancements() {
        if (typeof $.fn.flexslider === 'undefined') {
            return;
        }

        $('.woocommerce-product-gallery').on('click', '.flex-control-nav li', function () {
            $(this).addClass('flex-active').siblings().removeClass('flex-active');
        });
    }

    // Init on DOM ready
    $(document).ready(function () {
        initAjaxAddToCart();
        initVariationSwatches();
        initCartFragments();
        initCheckoutEnhancements();
        initGalleryEnhancements();
    });

})(jQuery);
