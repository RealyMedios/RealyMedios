(function ($) {
    'use strict';

    const $window = $(window);
    const $document = $(document);
    const $body = $('body');

    /**
     * Menu Toggle
     */
    function initMenuToggle() {
        const $toggle = $('.menu-toggle');
        const $overlay = $('.mobile-menu-overlay');
        const $panel = $('.mobile-menu-panel');
        const $close = $('.mobile-menu-close');

        $toggle.on('click', function () {
            const isActive = $(this).toggleClass('active').hasClass('active');
            $overlay.toggleClass('active', isActive);
            $panel.toggleClass('active', isActive);
            $(this).attr('aria-expanded', isActive);
            $body.toggleClass('menu-open', isActive);
        });

        $close.add($overlay).on('click', function () {
            $toggle.removeClass('active').attr('aria-expanded', 'false');
            $overlay.removeClass('active');
            $panel.removeClass('active');
            $body.removeClass('menu-open');
        });
    }

    /**
     * Search Toggle
     */
    function initSearchToggle() {
        const $toggle = $('.search-toggle');
        const $overlay = $('.search-overlay');
        const $close = $('.search-close');
        const $field = $('.search-field');

        $toggle.on('click', function () {
            $overlay.toggleClass('active');
            if ($overlay.hasClass('active')) {
                setTimeout(function () {
                    $field.focus();
                }, 200);
            }
        });

        $close.on('click', function () {
            $overlay.removeClass('active');
        });

        $document.on('keydown', function (e) {
            if (e.key === 'Escape') {
                $overlay.removeClass('active');
            }
        });
    }

    /**
     * Live Search
     */
    function initLiveSearch() {
        let searchTimer;
        const $field = $('.search-field');
        const $results = $('.search-results');

        $field.on('input', function () {
            clearTimeout(searchTimer);
            const query = $(this).val().trim();

            if (query.length < 2) {
                $results.removeClass('active').empty();
                return;
            }

            searchTimer = setTimeout(function () {
                $.post(ecotiendaData.ajaxUrl, {
                    action: 'ecotienda_search',
                    search: query,
                    nonce: ecotiendaData.nonce,
                }, function (data) {
                    $results.addClass('active');
                    if (data.length === 0) {
                        $results.html('<p class="no-results-msg">No se encontraron resultados</p>');
                        return;
                    }
                    let html = '<div class="search-results-list">';
                    data.forEach(function (item) {
                        html += '<a href="' + item.url + '" class="search-result-item">';
                        if (item.image) {
                            html += '<img src="' + item.image + '" alt="' + item.title + '" class="search-result-img"/>';
                        }
                        html += '<div class="search-result-info">';
                        html += '<span class="search-result-title">' + item.title + '</span>';
                        if (item.price) {
                            html += '<span class="search-result-price">' + item.price + '</span>';
                        }
                        html += '<span class="search-result-type">' + item.type + '</span>';
                        html += '</div></a>';
                    });
                    html += '</div>';
                    $results.html(html);
                });
            }, 400);
        });

        $document.on('click', function (e) {
            if (!$(e.target).closest('.search-overlay').length) {
                $results.removeClass('active');
            }
        });
    }

    /**
     * Sticky Header
     */
    function initStickyHeader() {
        let lastScroll = 0;
        const $header = $('.site-header');

        $window.on('scroll', function () {
            const currentScroll = $(this).scrollTop();
            if (currentScroll > 100) {
                $header.addClass('scrolled');
                if (currentScroll > lastScroll && currentScroll > 200) {
                    $header.addClass('header-hidden');
                } else {
                    $header.removeClass('header-hidden');
                }
            } else {
                $header.removeClass('scrolled header-hidden');
            }
            lastScroll = currentScroll;
        });
    }

    /**
     * Filter Toggle (Shop)
     */
    function initFilterToggle() {
        const $toggle = $('.filter-toggle');
        const $sidebar = $('.shop-sidebar');
        const $overlay = $('<div class="sidebar-overlay"></div>');

        $toggle.on('click', function () {
            $sidebar.toggleClass('active');
            if ($sidebar.hasClass('active')) {
                $body.append($overlay);
                $overlay.fadeIn(200);
            }
        });

        $body.on('click', '.sidebar-overlay', function () {
            $sidebar.removeClass('active');
            $(this).fadeOut(200, function () {
                $(this).remove();
            });
        });
    }

    /**
     * Smooth scroll for anchor links
     */
    function initSmoothScroll() {
        $document.on('click', 'a[href^="#"]', function (e) {
            const target = $(this.getAttribute('href'));
            if (target.length) {
                e.preventDefault();
                $('html, body').animate({
                    scrollTop: target.offset().top - 100,
                }, 600);
            }
        });
    }

    /**
     * Back to top
     */
    function initBackToTop() {
        const $btn = $('<button class="back-to-top" aria-label="Volver arriba">&uarr;</button>');
        $body.append($btn);

        $window.on('scroll', function () {
            $btn.toggleClass('visible', $(this).scrollTop() > 500);
        });

        $btn.on('click', function () {
            $('html, body').animate({ scrollTop: 0 }, 400);
        });
    }

    /**
     * Quantity input
     */
    function initQuantityInputs() {
        $document.on('click', '.quantity .plus, .quantity .minus', function () {
            const $input = $(this).closest('.quantity').find('.qty');
            const val = parseInt($input.val()) || 0;
            const step = parseInt($input.attr('step')) || 1;
            const min = parseInt($input.attr('min')) || 0;
            const max = parseInt($input.attr('max')) || 9999;

            if ($(this).hasClass('plus')) {
                $input.val(Math.min(val + step, max));
            } else {
                $input.val(Math.max(val - step, min));
            }
            $input.trigger('change');
        });
    }

    // Init on DOM ready
    $document.ready(function () {
        initMenuToggle();
        initSearchToggle();
        initLiveSearch();
        initStickyHeader();
        initFilterToggle();
        initSmoothScroll();
        initBackToTop();
        initQuantityInputs();
    });

})(jQuery);
