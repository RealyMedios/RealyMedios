<?php get_header(); ?>

<main id="primary" class="site-main">
    <div class="container">
        <header class="search-header">
            <h1 class="search-title">
                <?php printf(esc_html__('Resultados para: %s', 'ecotienda'), '<span>' . get_search_query() . '</span>'); ?>
            </h1>
        </header>

        <?php if (have_posts()) : ?>
            <div class="search-grid">
                <?php while (have_posts()) : the_post(); ?>
                    <?php get_template_part('template-parts/content', 'search'); ?>
                <?php endwhile; ?>
            </div>
            <?php the_posts_pagination([
                'mid_size' => 2,
                'prev_text' => __('&laquo;', 'ecotienda'),
                'next_text' => __('&raquo;', 'ecotienda'),
            ]); ?>
        <?php else : ?>
            <div class="no-results">
                <p><?php esc_html_e('No encontramos resultados para tu búsqueda. Intenta con otros términos.', 'ecotienda'); ?></p>
                <?php get_search_form(); ?>
            </div>
        <?php endif; ?>
    </div>
</main>

<?php get_footer(); ?>
