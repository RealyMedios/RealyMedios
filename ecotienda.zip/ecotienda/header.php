<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php
if (function_exists('wp_body_open')) {
    wp_body_open();
}
?>

<div id="page" class="site">
    <a class="skip-link screen-reader-text" href="#primary">
        <?php esc_html_e('Saltar al contenido', 'ecotienda'); ?>
    </a>

    <?php if (get_theme_mod('header_layout', 'default') !== 'transparent') : ?>
    <div class="top-bar">
        <div class="container">
            <div class="top-bar-inner">
                <div class="top-bar-left">
                    <span class="free-shipping">
                        &#10003; <?php esc_html_e('Envío gratis en pedidos +$50', 'ecotienda'); ?>
                    </span>
                </div>
                <div class="top-bar-right">
                    <?php if (class_exists('WooCommerce')) : ?>
                        <a href="<?php echo wc_get_page_permalink('myaccount'); ?>" class="top-bar-link">
                            <?php esc_html_e('Mi Cuenta', 'ecotienda'); ?>
                        </a>
                        <span class="top-bar-sep">|</span>
                        <a href="<?php echo wc_get_page_permalink('checkout'); ?>" class="top-bar-link">
                            <?php esc_html_e('Checkout', 'ecotienda'); ?>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <header id="masthead" class="site-header header-<?php echo esc_attr(get_theme_mod('header_layout', 'default')); ?>">
        <div class="container">
            <div class="header-inner">
                <div class="site-branding">
                    <?php if (has_custom_logo()) : ?>
                        <?php the_custom_logo(); ?>
                    <?php else : ?>
                        <a href="<?php echo esc_url(home_url('/')); ?>" rel="home" class="site-title">
                            <?php bloginfo('name'); ?>
                        </a>
                        <?php $description = get_bloginfo('description', 'display');
                        if ($description || is_customize_preview()) : ?>
                            <p class="site-description"><?php echo $description; ?></p>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>

                <button class="menu-toggle" aria-label="<?php esc_attr_e('Abrir menú', 'ecotienda'); ?>" aria-expanded="false">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>

                <nav id="site-navigation" class="main-navigation">
                    <?php
                    wp_nav_menu([
                        'theme_location' => 'primary',
                        'menu_id' => 'primary-menu',
                        'container' => false,
                        'fallback_cb' => false,
                    ]);
                    ?>
                </nav>

                <div class="header-actions">
                    <button class="search-toggle" aria-label="<?php esc_attr_e('Buscar', 'ecotienda'); ?>">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="11" cy="11" r="8"/>
                            <line x1="21" y1="21" x2="16.65" y2="16.65"/>
                        </svg>
                    </button>

                    <?php if (class_exists('WooCommerce')) : ?>
                        <a href="<?php echo wc_get_cart_url(); ?>" class="cart-icon">
                            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <circle cx="9" cy="21" r="1"/>
                                <circle cx="20" cy="21" r="1"/>
                                <path d="M1 1h4l2.68 13.39a2 2 0 002 1.61h9.72a2 2 0 002-1.61L23 6H6"/>
                            </svg>
                            <span class="cart-count">0</span>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="search-overlay">
            <div class="container">
                <form role="search" method="get" class="search-form" action="<?php echo esc_url(home_url('/')); ?>">
                    <input type="search" class="search-field" placeholder="<?php esc_attr_e('Buscar productos...', 'ecotienda'); ?>" value="<?php echo get_search_query(); ?>" name="s" autocomplete="off"/>
                    <input type="hidden" name="post_type" value="product"/>
                    <button type="submit" class="search-submit">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="11" cy="11" r="8"/>
                            <line x1="21" y1="21" x2="16.65" y2="16.65"/>
                        </svg>
                    </button>
                    <button type="button" class="search-close">&times;</button>
                </form>
                <div class="search-results"></div>
            </div>
        </div>
    </header>
