<?php if (post_password_required()) {
    return;
} ?>

<div id="comments" class="comments-area">
    <?php if (have_comments()) : ?>
        <h2 class="comments-title">
            <?php
            $comment_count = get_comments_number();
            printf(
                esc_html(_n('%s comentario', '%s comentarios', $comment_count, 'ecotienda')),
                number_format_i18n($comment_count)
            );
            ?>
        </h2>

        <ol class="comment-list">
            <?php
            wp_list_comments([
                'style' => 'ol',
                'short_ping' => true,
                'avatar_size' => 60,
            ]);
            ?>
        </ol>

        <?php the_comments_navigation(); ?>

        <?php if (!comments_open()) : ?>
            <p class="no-comments"><?php esc_html_e('Los comentarios están cerrados.', 'ecotienda'); ?></p>
        <?php endif; ?>
    <?php endif; ?>

    <?php comment_form([
        'title_reply_before' => '<h3 id="reply-title" class="comment-reply-title">',
        'title_reply_after' => '</h3>',
        'class_submit' => 'submit btn btn-primary',
    ]); ?>
</div>
