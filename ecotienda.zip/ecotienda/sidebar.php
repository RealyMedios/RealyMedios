<?php
$sidebar = 'sidebar-blog';
if (class_exists('WooCommerce') && (is_woocommerce() || is_cart() || is_checkout() || is_account_page())) {
    $sidebar = 'sidebar-shop';
}
?>
<?php if (is_active_sidebar($sidebar)) : ?>
    <aside id="secondary" class="widget-area">
        <?php dynamic_sidebar($sidebar); ?>
    </aside>
<?php endif; ?>
