<?php get_header(); ?>

<main id="primary" class="site-main">
    <div class="container">
        <header class="archive-header">
            <h1 class="archive-title">
                <?php the_archive_title(); ?>
            </h1>
            <?php the_archive_description('<div class="archive-description">', '</div>'); ?>
        </header>

        <?php if (have_posts()) : ?>
            <div class="blog-grid">
                <?php while (have_posts()) : the_post(); ?>
                    <?php get_template_part('template-parts/content', get_post_type()); ?>
                <?php endwhile; ?>
            </div>
            <?php the_posts_pagination([
                'mid_size' => 2,
                'prev_text' => __('&laquo;', 'ecotienda'),
                'next_text' => __('&raquo;', 'ecotienda'),
            ]); ?>
        <?php else : ?>
            <?php get_template_part('template-parts/content', 'none'); ?>
        <?php endif; ?>
    </div>
</main>

<?php get_footer(); ?>
