<?php
/**
 * Ecotienda Theme Functions
 */

define('ECOTIENDA_VERSION', '1.0.0');
define('ECOTIENDA_DIR', get_template_directory());
define('ECOTIENDA_URI', get_template_directory_uri());

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Theme Setup
 */
function ecotienda_setup() {
    add_theme_support('automatic-feed-links');
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', [
        'height'      => 100,
        'width'       => 300,
        'flex-height' => true,
        'flex-width'  => true,
    ]);
    add_theme_support('html5', [
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
        'navigation-widgets',
    ]);
    add_theme_support('align-wide');
    add_theme_support('responsive-embeds');
    add_theme_support('woocommerce');
    add_theme_support('wc-product-gallery-zoom');
    add_theme_support('wc-product-gallery-lightbox');
    add_theme_support('wc-product-gallery-slider');

    load_theme_textdomain('ecotienda', ECOTIENDA_DIR . '/languages');

    register_nav_menus([
        'primary' => __('Menú Principal', 'ecotienda'),
        'secondary' => __('Menú Secundario', 'ecotienda'),
        'footer' => __('Menú Footer', 'ecotienda'),
        'mobile' => __('Menú Móvil', 'ecotienda'),
    ]);

    set_post_thumbnail_size(800, 800, true);
    add_image_size('ecotienda-product', 600, 600, true);
    add_image_size('ecotienda-product-large', 1200, 1200, false);
    add_image_size('ecotienda-blog', 800, 500, true);
    add_image_size('ecotienda-banner', 1920, 600, true);
}
add_action('after_setup_theme', 'ecotienda_setup');

/**
 * Content Width
 */
function ecotienda_content_width() {
    $GLOBALS['content_width'] = apply_filters('ecotienda_content_width', 1200);
}
add_action('after_setup_theme', 'ecotienda_content_width', 0);

/**
 * Enqueue Scripts & Styles
 */
function ecotienda_scripts() {
    $version = ECOTIENDA_VERSION;

    wp_enqueue_style('ecotienda-main', ECOTIENDA_URI . '/assets/css/main.css', [], $version);
    wp_enqueue_style('ecotienda-woocommerce', ECOTIENDA_URI . '/assets/css/woocommerce.css', ['ecotienda-main'], $version);
    wp_enqueue_style('ecotienda-responsive', ECOTIENDA_URI . '/assets/css/responsive.css', ['ecotienda-main'], $version);

    if (is_rtl()) {
        wp_enqueue_style('ecotienda-rtl', ECOTIENDA_URI . '/assets/css/rtl.css', ['ecotienda-main'], $version);
    }

    wp_enqueue_script('ecotienda-main', ECOTIENDA_URI . '/assets/js/main.js', ['jquery'], $version, true);
    wp_enqueue_script('ecotienda-woocommerce', ECOTIENDA_URI . '/assets/js/woocommerce-custom.js', ['jquery'], $version, true);

    wp_localize_script('ecotienda-main', 'ecotiendaData', [
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('ecotienda_nonce'),
        'isMobile' => wp_is_mobile(),
    ]);

    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'ecotienda_scripts');

/**
 * Register Widget Areas
 */
function ecotienda_widgets_init() {
    $sidebars = [
        'sidebar-blog' => __('Sidebar Blog', 'ecotienda'),
        'sidebar-shop' => __('Sidebar Tienda', 'ecotienda'),
        'footer-1' => __('Footer Columna 1', 'ecotienda'),
        'footer-2' => __('Footer Columna 2', 'ecotienda'),
        'footer-3' => __('Footer Columna 3', 'ecotienda'),
        'footer-4' => __('Footer Columna 4', 'ecotienda'),
    ];

    foreach ($sidebars as $id => $name) {
        register_sidebar([
            'id' => $id,
            'name' => $name,
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget' => '</div>',
            'before_title' => '<h3 class="widget-title">',
            'after_title' => '</h3>',
        ]);
    }
}
add_action('widgets_init', 'ecotienda_widgets_init');

/**
 * Elementor Support
 */
function ecotienda_elementor_support() {
    if (did_action('elementor/loaded')) {
        add_theme_support('elementor');
        add_theme_support('elementor-pro');
        add_theme_support('header-footer-elementor');
    }
}
add_action('after_setup_theme', 'ecotienda_elementor_support');

/**
 * WooCommerce Setup
 */
function ecotienda_woocommerce_setup() {
    add_theme_support('woocommerce', [
        'product_grid' => [
            'default_rows' => 4,
            'min_rows' => 2,
            'max_rows' => 10,
            'default_columns' => 4,
            'min_columns' => 2,
            'max_columns' => 5,
        ],
    ]);
}
add_action('after_setup_theme', 'ecotienda_woocommerce_setup');

/**
 * Remove WooCommerce default styles
 */
add_filter('woocommerce_enqueue_styles', '__return_empty_array');

/**
 * WooCommerce Number of products per page
 */
function ecotienda_products_per_page() {
    return 16;
}
add_filter('loop_shop_per_page', 'ecotienda_products_per_page');

/**
 * WooCommerce Products per row
 */
function ecotienda_products_per_row() {
    return 4;
}
add_filter('loop_shop_columns', 'ecotienda_products_per_row');

/**
 * Custom breadcrumb

function ecotienda_breadcrumb() {
    if (function_exists('woocommerce_breadcrumb')) {
        woocommerce_breadcrumb([
            'delimiter' => '<span class="separator">›</span>',
            'wrap_before' => '<nav class="breadcrumb">',
            'wrap_after' => '</nav>',
            'before' => '<span>',
            'after' => '</span>',
        ]);
    }
}
*/

/**
 * Add custom body classes
 */
function ecotienda_body_classes($classes) {
    if (is_singular()) {
        $classes[] = 'singular';
    }
    if (is_active_sidebar('sidebar-blog') && is_single()) {
        $classes[] = 'has-sidebar';
    }
    if (class_exists('WooCommerce') && is_woocommerce()) {
        $classes[] = 'woocommerce-active';
    }
    if (class_exists('Elementor\Plugin') && \Elementor\Plugin::$instance->preview->is_preview_mode()) {
        $classes[] = 'elementor-edit-mode';
    }
    return $classes;
}
add_filter('body_class', 'ecotienda_body_classes');

/**
 * Custom login logo
 */
function ecotienda_login_logo() {
    ?>
    <style>
        #login h1 a {
            background-image: url(<?php echo ECOTIENDA_URI; ?>/assets/img/logo.svg);
            background-size: contain;
            width: 200px;
            height: 60px;
        }
    </style>
    <?php
}
add_action('login_head', 'ecotienda_login_logo');

/**
 * Customizer settings
 */
function ecotienda_customize_register($wp_customize) {
    $wp_customize->add_section('ecotienda_theme_options', [
        'title' => __('Ecotienda Opciones', 'ecotienda'),
        'priority' => 130,
    ]);

    $wp_customize->add_setting('primary_color', [
        'default' => '#5B8C5A',
        'sanitize_callback' => 'sanitize_hex_color',
    ]);
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'primary_color', [
        'label' => __('Color Principal', 'ecotienda'),
        'section' => 'ecotienda_theme_options',
    ]));

    $wp_customize->add_setting('secondary_color', [
        'default' => '#D4A373',
        'sanitize_callback' => 'sanitize_hex_color',
    ]);
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'secondary_color', [
        'label' => __('Color Secundario', 'ecotienda'),
        'section' => 'ecotienda_theme_options',
    ]));

    $wp_customize->add_setting('accent_color', [
        'default' => '#BC6C25',
        'sanitize_callback' => 'sanitize_hex_color',
    ]);
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'accent_color', [
        'label' => __('Color Acento', 'ecotienda'),
        'section' => 'ecotienda_theme_options',
    ]));

    $wp_customize->add_setting('header_layout', [
        'default' => 'default',
        'sanitize_callback' => 'sanitize_text_field',
    ]);
    $wp_customize->add_control('header_layout', [
        'label' => __('Diseño Header', 'ecotienda'),
        'section' => 'ecotienda_theme_options',
        'type' => 'select',
        'choices' => [
            'default' => __('Clásico', 'ecotienda'),
            'centered' => __('Centrado', 'ecotienda'),
            'transparent' => __('Transparente', 'ecotienda'),
        ],
    ]);
}
add_action('customize_register', 'ecotienda_customize_register');

/**
 * SVG Support
 */
function ecotienda_mime_types($mimes) {
    $mimes['svg'] = 'image/svg+xml';
    $mimes['webp'] = 'image/webp';
    return $mimes;
}
add_filter('upload_mimes', 'ecotienda_mime_types');

/**
 * Disable Gutenberg on WooCommerce pages
 */
function ecotienda_disable_gutenberg($current_status, $post_type) {
    if ($post_type === 'product') {
        return false;
    }
    return $current_status;
}
add_filter('use_block_editor_for_post_type', 'ecotienda_disable_gutenberg', 10, 2);

/**
 * AJAX add to cart for variable products
 */
function ecotienda_ajax_add_to_cart() {
    $product_id = intval($_POST['product_id']);
    $quantity = intval($_POST['quantity']);
    $variation_id = isset($_POST['variation_id']) ? intval($_POST['variation_id']) : 0;
    $variation = isset($_POST['variation']) ? $_POST['variation'] : [];

    if (WC()->cart->add_to_cart($product_id, $quantity, $variation_id, $variation)) {
        wp_send_json_success([
            'count' => WC()->cart->get_cart_contents_count(),
            'total' => WC()->cart->get_cart_total(),
            'message' => __('Producto agregado al carrito', 'ecotienda'),
        ]);
    } else {
        wp_send_json_error(['message' => __('Error al agregar al carrito', 'ecotienda')]);
    }
}
add_action('wp_ajax_ecotienda_add_to_cart', 'ecotienda_ajax_add_to_cart');
add_action('wp_ajax_nopriv_ecotienda_add_to_cart', 'ecotienda_ajax_add_to_cart');

/**
 * Mini cart fragment
 */
function ecotienda_mini_cart_fragment() {
    ob_start();
    ?>
    <span class="cart-count"><?php echo WC()->cart->get_cart_contents_count(); ?></span>
    <span class="cart-total"><?php echo WC()->cart->get_cart_total(); ?></span>
    <?php
    return ob_get_clean();
}

function ecotienda_header_add_to_cart_fragment($fragments) {
    $fragments['.cart-count'] = '<span class="cart-count">' . WC()->cart->get_cart_contents_count() . '</span>';
    $fragments['.cart-total'] = '<span class="cart-total">' . WC()->cart->get_cart_total() . '</span>';
    return $fragments;
}
add_filter('woocommerce_add_to_cart_fragments', 'ecotienda_header_add_to_cart_fragment');

/**
 * Custom search endpoint
 */
function ecotienda_ajax_search() {
    $search = sanitize_text_field($_POST['search']);
    $args = [
        'post_type' => ['product', 'post'],
        'posts_per_page' => 8,
        's' => $search,
        'post_status' => 'publish',
    ];
    $query = new WP_Query($args);
    $results = [];

    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            $results[] = [
                'title' => get_the_title(),
                'url' => get_permalink(),
                'image' => get_the_post_thumbnail_url(get_the_ID(), 'thumbnail'),
                'price' => class_exists('WooCommerce') && get_post_type() === 'product'
                    ? wc_price(get_post_meta(get_the_ID(), '_price', true))
                    : '',
                'type' => get_post_type(),
            ];
        }
        wp_reset_postdata();
    }

    wp_send_json($results);
}
add_action('wp_ajax_ecotienda_search', 'ecotienda_ajax_search');
add_action('wp_ajax_nopriv_ecotienda_search', 'ecotienda_ajax_search');

/**
 * Product quick view
 */
function ecotienda_quick_view() {
    $product_id = intval($_POST['product_id']);
    $product = wc_get_product($product_id);

    if (!$product) {
        wp_die();
    }

    wc_get_template_part('content', 'quick-view');
    wp_die();
}
add_action('wp_ajax_ecotienda_quick_view', 'ecotienda_quick_view');
add_action('wp_ajax_nopriv_ecotienda_quick_view', 'ecotienda_quick_view');

/**
 * Mobile menu fallback
 */
function ecotienda_mobile_fallback() {
    if (has_nav_menu('primary')) {
        $locations = get_nav_menu_locations();
        $menu = wp_get_nav_menu_object($locations['primary']);
        if ($menu) {
            $menu_items = wp_get_nav_menu_items($menu->term_id);
            echo '<ul class="mobile-menu">';
            foreach ($menu_items as $item) {
                echo '<li><a href="' . esc_url($item->url) . '">' . esc_html($item->title) . '</a></li>';
            }
            echo '</ul>';
        }
    } else {
        echo '<ul class="mobile-menu">';
        wp_list_pages([
            'title_li' => '',
            'depth' => 2,
        ]);
        echo '</ul>';
    }
}

/**
 * Customizer inline CSS (output on frontend only)
 */
function ecotienda_customizer_css_output() {
    $primary = get_theme_mod('primary_color', '#5B8C5A');
    $secondary = get_theme_mod('secondary_color', '#D4A373');
    $accent = get_theme_mod('accent_color', '#BC6C25');
    ?>
    <style>
        :root {
            --color-primary: <?php echo esc_attr($primary); ?>;
            --color-primary-dark: <?php echo esc_attr(ecotienda_adjust_brightness($primary, -15)); ?>;
            --color-primary-light: <?php echo esc_attr(ecotienda_adjust_brightness($primary, 20)); ?>;
            --color-secondary: <?php echo esc_attr($secondary); ?>;
            --color-secondary-dark: <?php echo esc_attr(ecotienda_adjust_brightness($secondary, -15)); ?>;
            --color-accent: <?php echo esc_attr($accent); ?>;
            --color-accent-dark: <?php echo esc_attr(ecotienda_adjust_brightness($accent, -15)); ?>;
        }
    </style>
    <?php
}
add_action('wp_head', 'ecotienda_customizer_css_output');

/**
 * Helper: adjust hex color brightness
 */
function ecotienda_adjust_brightness($hex, $steps) {
    $hex = str_replace('#', '', $hex);
    $r = max(0, min(255, hexdec(substr($hex, 0, 2)) + $steps));
    $g = max(0, min(255, hexdec(substr($hex, 2, 2)) + $steps));
    $b = max(0, min(255, hexdec(substr($hex, 4, 2)) + $steps));
    return '#' . dechex($r) . dechex($g) . dechex($b);
}
