<?php get_header(); ?>

<main id="primary" class="site-main error-404">
    <div class="container">
        <div class="error-page">
            <div class="error-code">404</div>
            <h1 class="error-title"><?php esc_html_e('Página no encontrada', 'ecotienda'); ?></h1>
            <p class="error-description">
                <?php esc_html_e('Lo sentimos, la página que buscas no existe o ha sido movida.', 'ecotienda'); ?>
            </p>
            <div class="error-actions">
                <a href="<?php echo esc_url(home_url('/')); ?>" class="btn btn-primary">
                    <?php esc_html_e('Volver al inicio', 'ecotienda'); ?>
                </a>
                <?php if (class_exists('WooCommerce')) : ?>
                    <a href="<?php echo esc_url(get_permalink(wc_get_page_id('shop'))); ?>" class="btn btn-secondary">
                        <?php esc_html_e('Ir a la tienda', 'ecotienda'); ?>
                    </a>
                <?php endif; ?>
            </div>
            <div class="error-search">
                <p><?php esc_html_e('¿O prefieres buscar?', 'ecotienda'); ?></p>
                <?php get_search_form(); ?>
            </div>
        </div>
    </div>
</main>

<?php get_footer(); ?>
