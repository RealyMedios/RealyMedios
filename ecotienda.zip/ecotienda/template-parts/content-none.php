<div class="no-content">
    <h2><?php esc_html_e('No hay contenido disponible', 'ecotienda'); ?></h2>
    <p><?php esc_html_e('Lo sentimos, no encontramos lo que buscas.', 'ecotienda'); ?></p>
    <?php get_search_form(); ?>
</div>
