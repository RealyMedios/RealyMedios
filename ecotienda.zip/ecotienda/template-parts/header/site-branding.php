<div class="site-branding">
    <?php if (has_custom_logo()) : ?>
        <?php the_custom_logo(); ?>
    <?php else : ?>
        <a href="<?php echo esc_url(home_url('/')); ?>" rel="home" class="site-title">
            <?php bloginfo('name'); ?>
        </a>
        <?php if (get_bloginfo('description')) : ?>
            <p class="site-description"><?php bloginfo('description'); ?></p>
        <?php endif; ?>
    <?php endif; ?>
</div>
