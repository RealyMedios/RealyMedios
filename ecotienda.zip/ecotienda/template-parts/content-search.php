<article id="post-<?php the_ID(); ?>" <?php post_class('search-card'); ?>>
    <a href="<?php the_permalink(); ?>" class="search-card-link">
        <?php if (has_post_thumbnail()) : ?>
            <div class="search-card-image">
                <?php the_post_thumbnail('thumbnail'); ?>
            </div>
        <?php endif; ?>
        <div class="search-card-body">
            <h3 class="search-card-title"><?php the_title(); ?></h3>
            <p class="search-card-excerpt"><?php echo wp_trim_words(get_the_excerpt(), 20); ?></p>
            <span class="search-card-type">
                <?php echo get_post_type_object(get_post_type())->labels->singular_name; ?>
            </span>
        </div>
    </a>
</article>
