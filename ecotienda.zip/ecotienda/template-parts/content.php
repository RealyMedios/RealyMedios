<article id="post-<?php the_ID(); ?>" <?php post_class('blog-card'); ?>>
    <?php if (has_post_thumbnail()) : ?>
        <a href="<?php the_permalink(); ?>" class="blog-card-image">
            <?php the_post_thumbnail('ecotienda-blog'); ?>
        </a>
    <?php endif; ?>
    <div class="blog-card-body">
        <div class="blog-card-meta">
            <span class="post-date"><?php echo get_the_date(); ?></span>
            <span class="post-category"><?php the_category(', '); ?></span>
        </div>
        <h2 class="blog-card-title">
            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
        </h2>
        <div class="blog-card-excerpt">
            <?php the_excerpt(); ?>
        </div>
        <a href="<?php the_permalink(); ?>" class="blog-card-link">
            <?php esc_html_e('Leer más', 'ecotienda'); ?> &rarr;
        </a>
    </div>
</article>
