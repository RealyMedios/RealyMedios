<div class="site-info">
    &copy; <?php echo date('Y'); ?>
    <a href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name'); ?></a>
    <?php esc_html_e('- Todos los derechos reservados.', 'ecotienda'); ?>
</div>
